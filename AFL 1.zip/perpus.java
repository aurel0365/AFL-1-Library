import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class perpus {
    private static ArrayList<String> bukuDipinjam = new ArrayList<>();
    private static ArrayList<String> dataBuku = new ArrayList<>();
    private static ArrayList<String> dataCD = new ArrayList<>();
    private static final double DENDA_PER_HARI = 1000;
    private static HashMap<String, Double> dendaMahasiswa = new HashMap<>();
    private static ArrayList<String> historyPeminjaman = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean loggedIn = false;
        String role = "";

        while (true) {
            System.out.println("===========================================");
            System.out.println("      Selamat datang di perpustakaan.    ");
            System.out.println("===========================================");
            System.out.println("Silakan pilih :");
            System.out.println("1. Login sebagai Mahasiswa");
            System.out.println("2. Login sebagai Dosen/Staff");
            System.out.println("3. Login sebagai Pustakawan");
            System.out.println("4. Keluar");
            System.out.print("Masukkan pilihan Anda: ");

            int pilihan = scanner.nextInt();

            switch (pilihan) {
                case 1:
                    role = "mahasiswa";
                    break;
                case 2:
                    role = "dosen/staff";
                    break;
                case 3:
                    role = "pustakawan";
                    break;
                case 4:
                    System.out.println("===========================================");
                    System.out.println("Terima kasih! Sampai jumpa lagi.");
                    System.out.println("===========================================");
                    System.exit(0);
                default:
                    System.out.println("Pilihan tidak valid.");
                    continue;
            }

            loggedIn = false;

            if (!loggedIn) {
                System.out.println("===========================================");
                System.out.println("               LOGIN                     ");
                System.out.println("===========================================");
                System.out.print("Username: ");
                String loginUsername = scanner.next();
                System.out.print("Password: ");
                String loginPassword = scanner.next();
                if (cekLogin(loginUsername, loginPassword, role)) {
                    System.out.println("===========================================");
                    System.out.println("           Login Berhasil                   ");
                    System.out.println("===========================================");
                    loggedIn = true;
                    if (role.equals("pustakawan")) {
                        menuPustakawan(scanner);
                    } else {
                        menuPeminjam(scanner);
                    }
                } else {
                    System.out.println("===========================================");
                    System.out.println("           Login Gagal                      ");
                    System.out.println("===========================================");
                }
            } else {
                System.out.println("Anda sudah login!");
            }
        }
    }

    private static boolean cekLogin(String username, String password, String role) {
        return username.length() >= 5 && password.length() >= 5;
    }

    private static void menuPeminjam(Scanner scanner) {
        ArrayList<String> dataBukuMahasiswa = new ArrayList<>(dataBuku);

        boolean continueLoop = true;
        while (continueLoop) {
            System.out.println("Silakan pilih tindakan:");
            System.out.println("1. Pinjam Buku");
            System.out.println("2. Pinjam CD");
            System.out.println("3. Pengembalian Buku");
            System.out.println("4. Pengembalian CD");
            System.out.println("5. Mencari Buku");
            System.out.println("6. Mencari CD");
            System.out.println("7. Perpanjang Peminjaman");
            System.out.println("8. Membayar denda peminjaman");
            System.out.println("9. Melihat denda peminjaman");
            System.out.println("10. Keluar");
            System.out.print("Masukkan pilihan Anda: ");

            int pilihan = scanner.nextInt();

            switch (pilihan) {
                case 1:
                    pinjamBuku(dataBukuMahasiswa);
                    break;
                case 2:
                    pinjamCD(dataCD);
                    break;
                case 3:
                    pengembalianBuku();
                    break;
                case 4:
                    pengembalianCD();
                    break;
                case 5:
                    cariBuku(dataBukuMahasiswa);
                    break;
                case 6:
                    cariCD(dataCD);
                    break;
                case 7:
                    perpanjangPeminjaman(scanner);
                    break;
                case 8:
                    bayarDenda(null);
                    break;
                case 9:
                    lihatDenda(null);
                    break;
                case 10:
                    continueLoop = false;
                    System.out.println("===========================================");
                    System.out.println("Terima kasih sudah datang di perpustakaan.");
                    System.out.println("===========================================");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
                    break;
            }
        }
    }

    private static void bayarDenda(String namaPengguna) {
        if (dendaMahasiswa.containsKey(namaPengguna)) {
            double denda = dendaMahasiswa.get(namaPengguna);
            System.out.println("Anda telah membayar denda sebesar: Rp " + denda);
            dendaMahasiswa.remove(namaPengguna);
        } else {
            System.out.println("Anda tidak memiliki denda untuk dibayar.");
        }
    }

    private static void lihatDenda(String namaPengguna) {
        if (dendaMahasiswa.containsKey(namaPengguna)) {
            double denda = dendaMahasiswa.get(namaPengguna);
            System.out.println("Denda Anda: Rp " + denda);
        } else {
            System.out.println("Anda tidak memiliki denda.");
        }
    }

    private static void pinjamCD(ArrayList<String> dataCD) {
        System.out.println("Daftar CD yang Tersedia:");
        tampilkanSemuaDataCD(dataCD);

        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan nomor CD yang ingin Anda pinjam atau ketik 0 untuk kembali: ");
        int nomorCD = scanner.nextInt();
        if (nomorCD == 0) {
            return;
        }
        boolean tersedia = cekKetersediaanCD(dataCD, nomorCD);
        if (tersedia) {
            String judulCD = dataCD.get(nomorCD - 1);
            bukuDipinjam.add(judulCD);
            System.out.println("Anda telah meminjam CD dengan judul '" + judulCD + "'.");
        } else {
            System.out.println("CD yang Anda pilih tidak tersedia. Silakan pilih CD lain.");
        }
    }

    private static boolean cekKetersediaanCD(ArrayList<String> dataCD, int nomorCD) {
        if (nomorCD >= 1 && nomorCD <= dataCD.size()) {
            String judulCD = dataCD.get(nomorCD - 1);
            return !bukuDipinjam.contains(judulCD);
        }
        return false;
    }

    private static void pengembalianCD() {
        Scanner scanner = new Scanner(System.in);
        if (bukuDipinjam.isEmpty()) {
            System.out.println("Tidak ada CD yang sedang dipinjam.");
        } else {
            System.out.println("Daftar CD yang Sedang Dipinjam:");
            for (int i = 0; i < bukuDipinjam.size(); i++) {
                System.out.println((i + 1) + ". " + bukuDipinjam.get(i));
            }
            System.out.print("Masukkan nomor CD yang akan dikembalikan: ");
            int nomorCD = scanner.nextInt();
            if (nomorCD >= 1 && nomorCD <= bukuDipinjam.size()) {
                String CDdikembalikan = bukuDipinjam.remove(nomorCD - 1);
                System.out.println("CD dengan judul '" + CDdikembalikan + "' telah dikembalikan.");
            } else {
                System.out.println("Nomor CD tidak valid.");
            }
        }
    }

    private static void cariCD(ArrayList<String> dataCD) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan judul CD yang ingin Anda cari: ");
        String judulCari = scanner.nextLine();

        boolean ditemukan = false;
        for (String judul : dataCD) {
            if (judul.toLowerCase().contains(judulCari.toLowerCase())) {
                System.out.println("CD dengan judul '" + judul + "' ditemukan.");
                ditemukan = true;
            }
        }

        if (!ditemukan) {
            System.out.println("CD dengan judul '" + judulCari + "' tidak ditemukan.");
        }
    }

    private static void pinjamBuku(ArrayList<String> dataBuku) {
        System.out.println("Daftar Buku yang Tersedia:");
        tampilkanSemuaDataBuku(dataBuku);

        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan nomor buku yang ingin Anda pinjam atau ketik 0 untuk kembali: ");
        int nomorBuku = scanner.nextInt();
        if (nomorBuku == 0) {
            return;
        }
        boolean tersedia = cekKetersediaanBuku(dataBuku, nomorBuku);
        if (tersedia) {
            String judulBuku = dataBuku.get(nomorBuku - 1);
            bukuDipinjam.add(judulBuku);
            System.out.println("Anda telah meminjam buku dengan judul '" + judulBuku + "'.");
        } else {
            System.out.println("Buku yang Anda pilih tidak tersedia. Silakan pilih buku lain.");
        }
    }

    private static boolean cekKetersediaanBuku(ArrayList<String> dataBuku, int nomorBuku) {
        if (nomorBuku >= 1 && nomorBuku <= dataBuku.size()) {
            String judulBuku = dataBuku.get(nomorBuku - 1);
            return !bukuDipinjam.contains(judulBuku);
        }
        return false;
    }

    private static void pengembalianBuku() {
        Scanner scanner = new Scanner(System.in);
        if (bukuDipinjam.isEmpty()) {
            System.out.println("Tidak ada buku yang sedang dipinjam.");
        } else {
            System.out.println("Daftar Buku yang Sedang Dipinjam:");
            for (int i = 0; i < bukuDipinjam.size(); i++) {
                System.out.println((i + 1) + ". " + bukuDipinjam.get(i));
            }
            System.out.print("Masukkan nomor buku yang akan dikembalikan: ");
            int nomorBuku = scanner.nextInt();
            if (nomorBuku >= 1 && nomorBuku <= bukuDipinjam.size()) {
                String bukuDikembalikan = bukuDipinjam.remove(nomorBuku - 1);
                System.out.println("Buku dengan judul '" + bukuDikembalikan + "' telah dikembalikan.");
            } else {
                System.out.println("Nomor buku tidak valid.");
            }
        }
    }

    private static void cariBuku(ArrayList<String> dataBuku) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan judul buku yang ingin Anda cari: ");
        String judulCari = scanner.nextLine();

        boolean ditemukan = false;
        for (String judul : dataBuku) {
            if (judul.toLowerCase().contains(judulCari.toLowerCase())) {
                System.out.println("Buku dengan judul '" + judul + "' ditemukan.");
                ditemukan = true;
            }
        }

        if (!ditemukan) {
            System.out.println("Buku dengan judul '" + judulCari + "' tidak ditemukan.");
        }
    }

    private static void perpanjangPeminjaman(Scanner scanner) {
        if (bukuDipinjam.isEmpty()) {
            System.out.println("Tidak ada buku yang sedang dipinjam.");
        } else {
            System.out.println("Daftar Buku yang Sedang Dipinjam:");
            for (int i = 0; i < bukuDipinjam.size(); i++) {
                System.out.println((i + 1) + ". " + bukuDipinjam.get(i));
            }
            System.out.print("Masukkan nomor buku yang akan diperpanjang peminjamannya: ");
            int nomorBuku = scanner.nextInt();
            if (nomorBuku >= 1 && nomorBuku <= bukuDipinjam.size()) {
                System.out.print("Masukkan jumlah hari untuk memperpanjang peminjaman: ");
                int jumlahHari = scanner.nextInt();
                if (jumlahHari > 0) {
                    System.out.println("Peminjaman buku berhasil diperpanjang selama " + jumlahHari + " hari.");
                } else {
                    System.out.println("Jumlah hari tidak valid.");
                }
            } else {
                System.out.println("Nomor buku tidak valid.");
            }
        }
    }

    private static void menuPustakawan(Scanner scanner) {
        boolean continueLoop = true;
        while (continueLoop) {
            System.out.println("Silakan pilih tindakan:");
            System.out.println("1. Claim Pengembalian");
            System.out.println("2. History Peminjaman");
            System.out.println("3. Mengelola Data Buku");
            System.out.println("4. Menambah Data CD");
            System.out.println("5. Cek Ketersediaan Buku");
            System.out.println("6. Cek Ketersediaan CD");
            System.out.println("7. Denda peminjaman");
            System.out.println("8. Keluar");
            System.out.print("Masukkan pilihan Anda: ");
            int pilihan = scanner.nextInt();

            switch (pilihan) {
                case 1:
                    claimPengembalian();
                    break;
                case 2:
                    lihatHistoryPeminjaman();
                    break;
                case 3:
                    kelolaDataBuku(scanner);
                    break;
                case 4:
                    tambahDataCD(scanner);
                    break;
                case 5:
                    cekKetersediaan(scanner);
                    break;
                case 6:
                    cekKetersediaanCD(scanner);
                    break;
                case 7:
                    dendaPeminjaman(scanner);
                    break;
                case 8:
                    continueLoop = false;
                    System.out.println("===========================================");
                    System.out.println("Terimakasih sudah datang di perpustakaan");
                    System.out.println("===========================================");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
                    break;
            }
        }
    }

    private static void dendaPeminjaman(Scanner scanner) {
        System.out.print("Masukkan jumlah hari keterlambatan: ");
        int daysLate = scanner.nextInt();

        double denda = daysLate * DENDA_PER_HARI;
        System.out.println("Denda yang harus dibayar: Rp " + denda);
    }

    private static void claimPengembalian() {
        Scanner scanner = new Scanner(System.in);
        if (bukuDipinjam.isEmpty()) {
            System.out.println("Tidak ada buku yang sedang dipinjam.");
        } else {
            System.out.println("Daftar Buku yang Sedang Dipinjam:");
            for (int i = 0; i < bukuDipinjam.size(); i++) {
                System.out.println((i + 1) + ". " + bukuDipinjam.get(i));
            }
            System.out.print("Masukkan nomor buku yang akan dikembalikan: ");
            int nomorBuku = scanner.nextInt();
            if (nomorBuku >= 1 && nomorBuku <= bukuDipinjam.size()) {
                String bukuDikembalikan = bukuDipinjam.remove(nomorBuku - 1);
                System.out.println("Buku dengan judul '" + bukuDikembalikan + "' telah dikembalikan.");
                beriDendaKeterlambatan(scanner);
            } else {
                System.out.println("Nomor buku tidak valid.");
            }
        }
    }

    private static void beriDendaKeterlambatan(Scanner scanner) {
        System.out.print("Apakah buku ini dikembalikan terlambat? (Ya/Tidak): ");
        String jawaban = scanner.next();
        if (jawaban.equalsIgnoreCase("Ya")) {
            System.out.print("Masukkan jumlah hari keterlambatan: ");
            int daysLate = scanner.nextInt();
            double denda = daysLate * DENDA_PER_HARI;
            System.out.println("Denda yang harus dibayar: Rp " + denda);
        }
    }

    private static void lihatHistoryPeminjaman() {
        if (historyPeminjaman.isEmpty()) {
            System.out.println("Tidak ada history peminjaman yang tersedia.");
        } else {
            System.out.println("History Peminjaman:");
            for (String history : historyPeminjaman) {
                System.out.println(history);
            }
        }
    }

    private static void kelolaDataBuku(Scanner scanner) {
        boolean continueLoop = true;
        while (continueLoop) {
            System.out.println("Silakan pilih tindakan:");
            System.out.println("1. Tambah Data Buku");
            System.out.println("2. Keluar");
            System.out.print("Masukkan pilihan Anda: ");
            int pilihan = scanner.nextInt();
    
            switch (pilihan) {
                case 1:
                    tambahDataBuku(scanner);
                    break;
                case 2:
                    continueLoop = false;
                    System.out.println("Keluar dari pengelolaan data buku.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
                    break;
            }
        }
    }
    
    private static void tambahDataBuku(Scanner scanner) {
        System.out.print("Masukkan jumlah buku yang ingin ditambahkan: ");
        int jumlahBuku = scanner.nextInt();
        scanner.nextLine();
    
        for (int i = 0; i < jumlahBuku; i++) {
            System.out.print("Masukkan judul buku " + (i + 1) + ": ");
            String judul = scanner.nextLine();
            dataBuku.add(judul);
        }
    
        System.out.println("Data buku berhasil ditambahkan.");
    }
    
    

    private static void tambahDataCD(Scanner scanner) {
        System.out.print("Masukkan jumlah data CD yang ingin ditambahkan: ");
        int jumlahData = scanner.nextInt();
    
        for (int i = 0; i < jumlahData; i++) {
            scanner.nextLine(); // Membersihkan newline di buffer
    
            System.out.print("Masukkan judul CD ke-" + (i + 1) + ": ");
            String judulCD = scanner.nextLine();
            dataCD.add(judulCD);
    
            System.out.println("CD dengan judul '" + judulCD + "' telah ditambahkan.");
        }
    }
    

    private static void cekKetersediaan(Scanner scanner) {
        if (dataBuku.isEmpty()) {
            System.out.println("Tidak ada buku yang tersedia saat ini.");
        } else {
            System.out.println("Daftar Buku yang Tersedia:");
            for (int i = 0; i < dataBuku.size(); i++) {
                System.out.println((i + 1) + ". " + dataBuku.get(i));
            }
            System.out.print("Masukkan nomor buku yang ingin Anda lihat ketersediaannya atau 0 untuk kembali: ");
            int nomorBuku = scanner.nextInt();
            scanner.nextLine(); 
            if (nomorBuku >= 1 && nomorBuku <= dataBuku.size()) {
                String judulBuku = dataBuku.get(nomorBuku - 1);
                System.out.println("Ketersediaan buku '" + judulBuku + "': Tersedia");
            } else if (nomorBuku == 0) {
                return;
            } else {
                System.out.println("Nomor buku tidak valid.");
            }
        }
    }    

    private static void cekKetersediaanCD(Scanner scanner) {
        if (dataCD.isEmpty()) {
            System.out.println("Tidak ada buku yang tersedia saat ini.");
        } else {
            System.out.println("Daftar Buku yang Tersedia:");
            for (int i = 0; i < dataCD.size(); i++) {
                System.out.println((i + 1) + ". " + dataCD.get(i));
            }
            System.out.print("Masukkan nomor CD yang ingin Anda lihat ketersediaannya atau 0 untuk kembali: ");
            int nomorCD = scanner.nextInt();
            scanner.nextLine(); 
            if (nomorCD >= 1 && nomorCD <= dataCD.size()) {
                String judulCD = dataCD.get(nomorCD - 1);
                System.out.println("Ketersediaan CD '" + judulCD + "': Tersedia");
            } else if (nomorCD == 0) {
                return;
            } else {
                System.out.println("Nomor CD tidak valid.");
            }
        }
    }    


    
    

    private static void tampilkanSemuaDataBuku(ArrayList<String> dataBuku) {
        for (int i = 0; i < dataBuku.size(); i++) {
            System.out.println((i + 1) + ". " + dataBuku.get(i));
        }
    }

    private static void tampilkanSemuaDataCD(ArrayList<String> dataCD) {
        for (int i = 0; i < dataCD.size(); i++) {
            System.out.println((i + 1) + ". " + dataCD.get(i));
        }
    }
}
