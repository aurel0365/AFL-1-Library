public class cd {
    private String judulCD;
    private String artis;
    private String tahunterbit;
    public int nomorCD;
    
    public cd(String judul, String artis, String tahunterbit,int idCD) {
        this.judulCD = judul;
        this.artis = artis;
        this.tahunterbit = tahunterbit;
        this.nomorCD=idCD;
    }

    public String getJudul() {
        return judulCD;
    }

    public void setJudul(String judul) {
        this.judulCD = judul;
    }

    public String getArtis() {
        return artis;
    }

    public void setArtis(String artis) {
        this.artis = artis;
    }

    public String getTahunterbit() {
        return tahunterbit;
    }

    public void setTahunterbit(String tahunterbit) {
        this.tahunterbit = tahunterbit;
    }

    public int getIdCD() {
        return nomorCD;
    }

    public void setIdCD(int idCD) {
        this.nomorCD = idCD;
    }
    public String toString() {
        return "CD{" +
                "kodeCD='" + nomorCD + '\'' +
                ", tahunTerbit=" + tahunterbit +
                '}';
    }
    
}