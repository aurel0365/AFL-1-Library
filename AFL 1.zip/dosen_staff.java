public class dosen_staff {
    private String nama;
    private int nik;
    private int idStaff;
    private String username;
    private String alamat;
    private String nomorHP;
    private String status;

    public dosen_staff(String nama,int nik, int idStaff, String username, String alamat, String nomorHP, String status) {
        this.nama = nama;
        this.nik=nik;
        this.idStaff = idStaff;
        this.username = username;
        this.alamat = alamat;
        this.nomorHP = nomorHP;
        this.status = status;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getIdStaff() {
        return idStaff;
    }

    public void setIdStaff(int idStaff) {
        this.idStaff = idStaff;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getNomorHP() {
        return nomorHP;
    }

    public void setNomorHP(String nomorHP) {
        this.nomorHP = nomorHP;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getNik() {
        return nik;
    }

    public void setNik(int nik) {
        this.nik = nik;
    }

    
}