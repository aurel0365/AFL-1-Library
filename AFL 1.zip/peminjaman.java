public class peminjaman {
    private int idPeminjaman;
    private int idpengembalian;
    private String tanggalPinjam;
    private String tanggalKembali;
    private String buku;
    private String ID_Koleksi;
    private String Kode_CD;

    public peminjaman(int idPeminjaman, int idpengembalian, String tanggalPinjam, String tanggalKembali, String buku,
            String iD_Koleksi, String kode_CD) {
        this.idPeminjaman = idPeminjaman;
        this.idpengembalian = idpengembalian;
        this.tanggalPinjam = tanggalPinjam;
        this.tanggalKembali = tanggalKembali;
        this.buku = buku;
        ID_Koleksi = iD_Koleksi;
        Kode_CD = kode_CD;
    }

    public int getIdPeminjaman() {
        return idPeminjaman;
    }

    public void setIdPeminjaman(int idPeminjaman) {
        this.idPeminjaman = idPeminjaman;
    }

    public int getIdpengembalian() {
        return idpengembalian;
    }

    public void setIdpengembalian(int idpengembalian) {
        this.idpengembalian = idpengembalian;
    }

    public String getTanggalPinjam() {
        return tanggalPinjam;
    }

    public void setTanggalPinjam(String tanggalPinjam) {
        this.tanggalPinjam = tanggalPinjam;
    }

    public String getTanggalKembali() {
        return tanggalKembali;
    }

    public void setTanggalKembali(String tanggalKembali) {
        this.tanggalKembali = tanggalKembali;
    }

    public String getBuku() {
        return buku;
    }

    public void setBuku(String buku) {
        this.buku = buku;
    }

    public String getID_Koleksi() {
        return ID_Koleksi;
    }

    public void setID_Koleksi(String iD_Koleksi) {
        ID_Koleksi = iD_Koleksi;
    }

    public String getKode_CD() {
        return Kode_CD;
    }

    public void setKode_CD(String kode_CD) {
        Kode_CD = kode_CD;
    }

}