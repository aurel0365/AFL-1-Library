public class staff {
    private String nama;
    private int idStaff;
    private String username;

public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

public staff(String nama,int idStaff) {
    this.nama = nama;
    this.idStaff = idStaff;
}

public String getNama() {
    return nama;
}

public void setNama(String nama) {
    this.nama = nama;
}

public int getIdStaff() {
    return idStaff;
}

public void setIdStaff(int idStaff) {
    this.idStaff = idStaff;
}

}

