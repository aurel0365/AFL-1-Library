public class pustakawan {
    private String nama;
    private String password;
    private String username;

    public pustakawan(String nama, String password, String username) {
        this.nama = nama;
        this.password = password;
        this.username = username;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    
}
