
public class pengembalian {
    private int idPengembalian;
    private String tanggalPengembalian;
    private double denda;
    private String peminjaman;
    
    public pengembalian(int idPengembalian, String tanggalPengembalian, double denda, String peminjaman) {
        this.idPengembalian = idPengembalian;
        this.tanggalPengembalian = tanggalPengembalian;
        this.denda = denda;
        this.peminjaman = peminjaman;
    }

    public int getIdPengembalian() {
        return idPengembalian;
    }

    public void setIdPengembalian(int idPengembalian) {
        this.idPengembalian = idPengembalian;
    }

    public String getTanggalPengembalian() {
        return tanggalPengembalian;
    }

    public void setTanggalPengembalian(String tanggalPengembalian) {
        this.tanggalPengembalian = tanggalPengembalian;
    }

    public double getDenda() {
        return denda;
    }

    public void setDenda(double denda) {
        this.denda = denda;
    }

    public String getPeminjaman() {
        return peminjaman;
    }

    public void setPeminjaman(String peminjaman) {
        this.peminjaman = peminjaman;
    }

   
}


