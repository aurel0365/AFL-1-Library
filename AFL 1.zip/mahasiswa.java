public class mahasiswa {
    private String nama;
    private String nim;
    private String jurusan;
    private int semester;
    private String email;
    private String password;


public mahasiswa(String nama, String nim, String jurusan, int semester, String email, String password) {
    this.nama = nama;
    this.nim = nim;
    this.jurusan =jurusan;
    this.semester = semester;
    this.email = email;
    this.password = password;
}


public String getNama() {
    return nama;
}


public void setNama(String nama) {
    this.nama = nama;
}


public String getNim() {
    return nim;
}


public void setNim(String nim) {
    this.nim = nim;
}


public String getJurusan() {
    return jurusan;
}


public void setJurusan(String jurusan) {
    this.jurusan = jurusan;
}


public int getSemester() {
    return semester;
}


public void setSemester(int semester) {
    this.semester = semester;
}


public String getEmail() {
    return email;
}


public void setEmail(String email) {
    this.email = email;
}


public String getPassword() {
    return password;
}


public void setPassword(String password) {
    this.password = password;
}


}



