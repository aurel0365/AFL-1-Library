public class transaksi {
    private mahasiswa peminjam;
    private buku buku;
    private String tanggalPinjam;
    private String tanggalKembali;
    private String daftarTransaksi;

    public transaksi(mahasiswa peminjam, buku buku, String tanggalPinjam, String tanggalKembali) {
        this.peminjam = peminjam;
        this.buku = buku;
        this.tanggalPinjam = tanggalPinjam;
        this.tanggalKembali = tanggalKembali;
    }

    public mahasiswa getPeminjam() {
        return peminjam;
    }

    public void setPeminjam(mahasiswa peminjam) {
        this.peminjam = peminjam;
    }

    public buku getBuku() {
        return buku;
    }

    public void setBuku(buku buku) {
        this.buku = buku;
    }

    public String getTanggalPinjam() {
        return tanggalPinjam;
    }

    public void setTanggalPinjam(String tanggalPinjam) {
        this.tanggalPinjam = tanggalPinjam;
    }

    public String getTanggalKembali() {
        return tanggalKembali;
    }

    public void setTanggalKembali(String tanggalKembali) {
        this.tanggalKembali = tanggalKembali;
    }

    public String getDaftarTransaksi() {
        return daftarTransaksi;
    }

    public void setdaftarTransaksi(String daftarTransaksi) {
        this.daftarTransaksi = daftarTransaksi;
    }
    

   
}
